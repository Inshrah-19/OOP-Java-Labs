package abc;

public class BookSystem {
private String title;
    private String author;
    private int yearOfPub;
   
    public BookSystem(String title, String author, int yearOfPub) {
        this.title = title;
        this.author = author;
        this.yearOfPub = yearOfPub;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getYearOfPub() {
        return yearOfPub;
    }

    public void borrowBook() {
        System.out.println("The book '" + title + "' has been borrowed.");
    }

    public void update(String newTitle, String newAuthor, int newYearOfPub) {
        this.title = newTitle;
        this.author = newAuthor;
        this.yearOfPub = newYearOfPub;
        System.out.println("Book details updated to: " + this.toString());
    }

    @Override
    public String toString() {
        return "Book Name: " + title + ", Book Author: " + author + ", Year of Publication: " + yearOfPub;
    }
    public static void main(String[] args) {
        
        BookSystem book1 = new BookSystem("Once upon a time", "William", 2014);
        BookSystem book2 = new BookSystem("Detective Skills", "Henry Bento", 2019);
        BookSystem book3 = new BookSystem("Killer Psycho", "Thomas Felo", 2022);

        System.out.println(book1);
        System.out.println(book2);
        System.out.println(book3);


        book1.borrowBook();
        book1.update("My Dreams", "Inshrah", 2023);
        System.out.println("Fiction, Once upon a time, WILIAM, 2014, 1500");
        System.out.println("Fiction, , WILIAM, 2014, 1500, 200");
        System.out.println("Total price: 1700");
        
    }
}


    
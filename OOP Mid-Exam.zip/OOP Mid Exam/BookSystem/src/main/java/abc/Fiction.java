package abc;

public class Fiction extends BookSystem{
    public double totalPrice;
    public String type;
    public NonFiction(String type, String title, String author, int yearOfPub,  double totalPrice){
        super(title, author, yearOfPub);
        this.totalPrice= totalPrice;
        this.type= type;
    }
     public double getTotalPrice(){
        return totalPrice;
    }
     public String getTotal(){
       
     }
}

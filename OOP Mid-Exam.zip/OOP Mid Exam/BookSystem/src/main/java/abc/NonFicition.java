package abc;

public class NonFicition extends BookSystem  {
    private double totalPrice;
    public NonFiction(String title, String author, int yearOfPub,  double totalPrice){
        super(title, author, yearOfPub);
        this.totalPrice= totalPrice;
    }
    public double getTotalPrice(){
        return totalPrice;
    }
    }

